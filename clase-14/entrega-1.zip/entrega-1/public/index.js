//Edit
let editForm = document.querySelector("#editForm");
const sendPr = (e) => {
	if (e) e.preventDefault();
	let idPr = document.querySelector("#idPr").value;
	let timestampPr = new Date();
	let titlePr = document.querySelector("#titlePr").value;
	let descriptionPr = document.querySelector("#descriptionPr").value;
	let codePr = document.querySelector("#codePr").value;
	let thumbnailPr = document.querySelector("#thumbnailPr").value;
	let pricePr = document.querySelector("#pricePr").value;
	let stockPr = document.querySelector("#stockPr").value;
	//No me toma el req.body que le envio, me llega un objeto vacio. Con postman todo Ok
	fetch("/api/products/" + idPr + "?admin=true", {
		method: "PUT",
		body: {
			id: idPr,
			timestamp: timestampPr,
			title: titlePr,
			description: descriptionPr,
			code: codePr,
			thumbnail: thumbnailPr,
			price: pricePr,
			stock: stockPr,
		},
	}).then((response) => {
		return response.json();
	});
};
if (editForm) {
	editForm.addEventListener("submit", sendPr);
}

//Delete
const sendId = (id) => {
	fetch("/api/products/" + id + "?admin=true", {
		method: "DELETE",
	});
};

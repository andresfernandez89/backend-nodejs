const express = require("express");
const {Router} = express;
const router = new Router();

//Class Contenedor
const Cart = require("../classes/cart");
const cart = new Cart("./data/cart.txt");

//Add
router.post("/", (req, res) => {
	let obj = {timestamp: new Date(), ...req.body};
	cart.saveCart(obj);
	res.send("Cart Created");
});

//Delete
router.delete("/:id", (req, res) => {});

module.exports = router;

const helpers = require("../helpers");

class Cart {
	constructor(path) {
		this.carts = [];
		this.path = path;
	}

	async saveCart(cart) {
		const fileExists = await helpers.readFile(this.path);
		if (fileExists && fileExists.length >= 0) {
			let objFile = JSON.parse(fileExists);
			let arr = objFile.map((element) => {
				return element.id;
			});
			let maxArr = Math.max(...arr);
			let id = maxArr + 1;
			let pr = {id, ...cart};
			objFile.push(pr);
			this.carts = objFile;
			helpers.writeFile(this.carts, this.path);
			return cart.id;
		} else {
			let id = 1;
			let pr = {id, ...cart};
			this.carts.push(pr);
			helpers.writeFile(this.carts, this.path);
		}
	}
}

module.exports = Cart;
